/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pokemon_pokedex;

import pokemon_dato.Pokemon;

/**
 *
 * @author Ignac
 */
public class ListaSimplePokemon {
    private NodoPokemon cabeza;
    
    public ListaSimplePokemon(){
        this.cabeza = null;
    }
    
    /*Crea un nuevo nodo e inserta el nuevo pokemon, luego consulta la informacion
    del nuevo nodo y la compara contra los nodos de la lista para insertar el dato*/
    
    public void inserta(Pokemon pokemon){
   
        if (cabeza == null){
            cabeza = new NodoPokemon(pokemon);
        } else if ( pokemon.getId() < cabeza.getPokemon().getId()){
            NodoPokemon nuevo = new NodoPokemon(pokemon);
            nuevo.setNext(cabeza);
            cabeza = nuevo;
        } else if( cabeza.getNext() == null){
            cabeza.setNext(new NodoPokemon(pokemon));
        }
        else {
            
            NodoPokemon aux = cabeza;
            
            while(aux.getNext()!=null 
                    && aux.getNext().getPokemon().getId()< pokemon.getId()){
                aux = aux.getNext();
            }
            
            NodoPokemon temp = new NodoPokemon(pokemon);
            temp.setNext(aux.getNext());
            aux.setNext(temp);
        }
    }

    public NodoPokemon getCabeza() {
        return cabeza;
    }
    
    public String toString(){
        NodoPokemon aux = cabeza;
        String s = "";
        while(aux!= null){
            s += "ID: " + aux.getPokemon().getId() + " , " 
                    +"Nombre: "+ aux.getPokemon().getNombre()+
                    "\n";
            aux = aux.getNext();
        }
        return s;
    }
    
}
