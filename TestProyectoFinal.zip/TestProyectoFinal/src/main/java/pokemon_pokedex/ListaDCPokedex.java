/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pokemon_pokedex;

import pokemon_dato.Pokemon;

/**
 *
 * @author Ignac
 */

public class ListaDCPokedex {

    private NodoPokedex cabeza;
    private NodoPokedex ultimo;

    public ListaDCPokedex() {
        this.cabeza = null;
        this.ultimo = null;
    }

    public void inserta(Pokemon pokemon) {
        NodoPokedex nuevo = new NodoPokedex(pokemon);

        if (cabeza == null) {  // La lista está vacía
            cabeza = nuevo;
            ultimo = cabeza;
            ultimo.setBack(cabeza);
            cabeza.setNext(ultimo);
        } else if (nuevo.getPokemon().getId() < cabeza.getPokemon().getId()) {  // Insertar al principio
            nuevo.setNext(cabeza);
            cabeza.setBack(nuevo);
            cabeza = nuevo;
            ultimo.setNext(cabeza);
            cabeza.setBack(ultimo);
        } else if (ultimo.getPokemon().getId() <= pokemon.getId()) {  // Insertar al final
            ultimo.setNext(nuevo);
            nuevo.setBack(ultimo);
            ultimo = nuevo;  // Actualizar correctamente el último nodo
            ultimo.setNext(cabeza);
            cabeza.setBack(ultimo);
        } else {  // Insertar en medio
            NodoPokedex aux = cabeza;
            while (aux.getNext().getPokemon().getId() < pokemon.getId()) {
                aux = aux.getNext();
            }
            nuevo.setNext(aux.getNext());
            nuevo.setBack(aux);
            aux.getNext().setBack(nuevo);
            aux.setNext(nuevo);
        }
    }

    public String toString() {
        
        NodoPokedex aux = cabeza;
        String s = "";
        if(aux != null ){
            do{
            s += "Nombre: " + aux.getPokemon().getNombre() +
                    "ID: " + aux.getPokemon().getId() +
                    "\n";
            aux = aux.getNext();
            }while(aux!=cabeza);
        }
        return s;
    }
}
