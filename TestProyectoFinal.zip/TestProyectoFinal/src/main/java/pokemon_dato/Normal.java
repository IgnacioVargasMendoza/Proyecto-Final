/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pokemon_dato;

/**
 *
 * @author Ignac
 */
public class Normal extends Pokemon {
    
        public Normal(String nombre) {
        super(nombre);

      
    }

    @Override
    public void ataqueEspecial() {
        System.out.println("ataque especial Normal");
    }

    @Override
    public void defensaEspecial() {
        System.out.println("defensa especial Normal");
    }

}
